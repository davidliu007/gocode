binary_tree_code_write << EOF
1
1485
11
6
dotfiles
GPGACODE_dat
/discover/nobackup/yliu7/gpcode/GPCODE4ship/pts/Trees/Train_SeaWiFS_V19_SSE1k_NoBS08/
EOF
